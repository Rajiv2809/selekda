<?php

namespace App\Http\Controllers;

use App\Http\Requests\BlogCommentRequest;
use Illuminate\Http\Request;

class BlogCommentController extends Controller
{
    public function create(BlogCommentRequest $request ) {
        
    }
}
